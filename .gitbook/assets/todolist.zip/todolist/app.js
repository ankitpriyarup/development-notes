const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const date = require(__dirname + "/date.js");
const _ = require("lodash");

const app = express();
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
mongoose.connect("mongodb://localhost:27017/todolistDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const itemsSchema = new mongoose.Schema({ name: String });
const listsSchema = new mongoose.Schema({ name: String, items: [itemsSchema] });
const Item = mongoose.model("Item", itemsSchema);
const List = mongoose.model("List", listsSchema);

app.get("/", function (req, res) {
  res.redirect("/Today");
});
app.get("/:customListName", function (req, res) {
  const listName = _.capitalize(req.params.customListName);
  let day = date.getDate();
  List.findOne({ name: listName }, function (err, foundList) {
    if (!err) {
      if (!foundList) {
        new List({ name: listName, items: [] }).save();
        res.redirect("/" + listName);
      } else {
        res.render("list", {
          listTitle: listName,
          date: day,
          taskList: foundList.items,
        });
      }
    }
  });
});

app.post("/add", function (req, res) {
  List.findOne({ name: req.body.listName }, function (err, foundList) {
    if (!err) {
      foundList.items.push(new Item({ name: req.body.itemName }));
      foundList.save();
      res.redirect("/" + req.body.listName);
    } else {
      res.redirect("/");
    }
  });
});
app.post("/delete", function (req, res) {
  const checkedTaskId = req.body.check;
  List.findOneAndUpdate(
    { name: req.body.listName },
    { $pull: { items: { _id: checkedTaskId } } },
    function (err, foundList) {
      if (!err) {
        res.redirect("/" + req.body.listName);
      }
    }
  );
});

app.listen(3000, function () {
  console.log("Server started on port 3000!");
});
